package com.rtm_backend.primary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
